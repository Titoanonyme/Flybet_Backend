
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///flybet.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Models
class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sport = db.Column(db.String(50), nullable=False)
    teams = db.Column(db.String(100), nullable=False)
    odds = db.Column(db.JSON, nullable=False)

# Initialize database
@app.before_first_request
def create_tables():
    db.create_all()

# Endpoints
@app.route('/events', methods=['GET'])
def get_events():
    events = Event.query.all()
    return jsonify([{"id": e.id, "sport": e.sport, "teams": e.teams, "odds": e.odds} for e in events])

@app.route('/add-event', methods=['POST'])
def add_event():
    data = request.get_json()
    new_event = Event(sport=data['sport'], teams=data['teams'], odds=data['odds'])
    db.session.add(new_event)
    db.session.commit()
    return jsonify({"message": "Event added", "event": {"id": new_event.id, "sport": new_event.sport, "teams": new_event.teams, "odds": new_event.odds}}), 201

@app.route('/calculate-odds', methods=['POST'])
def calculate_odds():
    data = request.get_json()
    outcome = data.get("outcome")
    stake = data.get("stake")
    odds = data.get("odds")
    if not outcome or not stake or not odds:
        return jsonify({"error": "Invalid input"}), 400
    potential_win = stake * odds.get(outcome, 0)
    return jsonify({"outcome": outcome, "stake": stake, "potential_win": potential_win})

if __name__ == '__main__':
    app.run(debug=True)
